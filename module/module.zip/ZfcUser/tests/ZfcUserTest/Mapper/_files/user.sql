
INSERT INTO user (username,email,display_name,password,state)
VALUES ('zfc-user', 'zfc-user@github.com', 'Zfc-User', 'c4zyP455w0rd!',1);

INSERT INTO user (username,email,display_name,password,state)
VALUES ('zfc-user2', 'zfc-user2@github.com', 'Zfc-User2', 'c4zyP455w0rd!',1);

INSERT INTO user (username,email,display_name,password,state)
VALUES ('zfc-user3', 'zfc-user@trash-mail.com', 'Zfc-User3', 'c4zyP455w0rd!',1);
