<?php

namespace ZfcUser\Validator\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
