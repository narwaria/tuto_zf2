<?php

namespace ZfcUser\Validator\Exception;

interface ExceptionInterface
{
}
