<?php

namespace ZfcUser\Authentication\Adapter\Exception;

use Zend\Math\Exception\RuntimeException;

class OptionsNotFoundException extends RuntimeException
{

}
