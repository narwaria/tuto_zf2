<?php

namespace ZfcUser\Exception;

interface ExceptionInterface
{
}
