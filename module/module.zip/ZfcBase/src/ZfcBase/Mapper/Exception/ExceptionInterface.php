<?php

namespace ZfcBase\Mapper\Exception;

interface ExceptionInterface
{}