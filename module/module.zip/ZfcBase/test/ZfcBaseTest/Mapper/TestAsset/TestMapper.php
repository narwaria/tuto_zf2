<?php

namespace ZfcBaseTest\Mapper\TestAsset;

use ZfcBase\Mapper\AbstractDbMapper;

class TestMapper extends AbstractDbMapper
{

}
